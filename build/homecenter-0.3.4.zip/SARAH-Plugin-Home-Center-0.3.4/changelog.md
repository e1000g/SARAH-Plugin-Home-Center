Version 0.3.2 (26/01/2016) <br />
— forced turnOn if setValue undefined<br />
— modified console logs<br />
— code cleaning <br />

Version 0.3.1 (25/01/2016) <br />
— bugfix : replaced body.properties.value with body.properties['ui.VoletDIM.value'] in virtual_device<br />

Version 0.3.0 (25/01/2016) <br />
— support du plugin Logitech Harmony<br />

Version 0.2.1 (24/01/2016) <br />
— support des modules virtuels : sliders<br />

Version 0.2.0 (23/01/2016) <br />
— support des modules virtuels : boutons<br />

Version 0.1.2 (22/01/2016) <br />
— support du module météo<br />

Version 0.1.1 (21/01/2016) <br />
— support des sondes<br />

Version 0.1.0 (20/01/2016) <br />
— support des binarySwitch multilevelSwitch<br />
