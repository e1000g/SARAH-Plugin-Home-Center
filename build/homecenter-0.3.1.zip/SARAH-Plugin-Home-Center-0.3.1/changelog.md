Version 0.3.0 (25/01/2016) : support du plugin Logitech Harmony<br />
Version 0.2.1 (24/01/2016) : support des modules virtuels : sliders<br />
Version 0.2.0 (23/01/2016) : support des modules virtuels : boutons<br />
Version 0.1.2 (22/01/2016) : support du module météo<br />
Version 0.1.1 (21/01/2016) : support des sondes<br />
Version 0.1.0 (20/01/2016) : support des binarySwitch multilevelSwitch<br />
